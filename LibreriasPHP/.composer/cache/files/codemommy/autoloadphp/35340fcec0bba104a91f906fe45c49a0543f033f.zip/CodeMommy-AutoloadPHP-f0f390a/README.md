# CodeMommy AutoloadPHP

[![Minimum PHP Version](https://img.shields.io/badge/php->=5.3-8892BF.svg)](https://php.net)
[![License](https://poser.pugx.org/CodeMommy/AutoloadPHP/license)](LICENSE)
[![Download](https://poser.pugx.org/CodeMommy/AutoloadPHP/downloads)](https://packagist.org/packages/CodeMommy/AutoloadPHP)
[![Stable](https://poser.pugx.org/CodeMommy/AutoloadPHP/version)](https://packagist.org/packages/CodeMommy/AutoloadPHP)
[![Unstable](https://poser.pugx.org/CodeMommy/AutoloadPHP/v/unstable)](https://packagist.org/packages/CodeMommy/AutoloadPHP)
[![composer.lock Available](https://poser.pugx.org/CodeMommy/AutoloadPHP/composerlock)](https://packagist.org/packages/CodeMommy/AutoloadPHP)
[![Build Status](https://travis-ci.org/CodeMommy/AutoloadPHP.svg?branch=master)](https://travis-ci.org/CodeMommy/AutoloadPHP)
[![Coverage Status](https://coveralls.io/repos/github/CodeMommy/AutoloadPHP/badge.svg?branch=master)](https://coveralls.io/github/CodeMommy/AutoloadPHP?branch=master)

> Automatic load namespaces, classes and files

## Manual

- [Version 1.0 简体中文](manual/1.0_SimplifiedChinese.md)

## Contributor

- [Candison November](http://www.kandisheng.com) - Founder

## Information

- [Homepage](http://www.CodeMommy.com)
- [GitHub](https://github.com/CodeMommy/AutoloadPHP)
- [Packagist](https://packagist.org/packages/CodeMommy/AutoloadPHP)
- [Feedback](https://github.com/CodeMommy/AutoloadPHP/issues)
- [About CodeMommy](https://github.com/CodeMommy/CodeMommy)