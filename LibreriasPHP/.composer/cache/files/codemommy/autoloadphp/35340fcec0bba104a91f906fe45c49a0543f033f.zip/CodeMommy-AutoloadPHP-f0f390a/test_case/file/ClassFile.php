<?php

/**
 * CodeMommy AutoloadPHP
 * @author Candison November <www.kandisheng.com>
 */

namespace Root\NamespaceFile;

/**
 * Class ClassFile
 * @package Root\NamespaceFile
 */
class ClassFile
{
    /**
     * ClassFile constructor.
     */
    public function __construct()
    {
    }

    /**
     * @return string
     */
    public static function show()
    {
        return 'ClassFile';
    }
}
