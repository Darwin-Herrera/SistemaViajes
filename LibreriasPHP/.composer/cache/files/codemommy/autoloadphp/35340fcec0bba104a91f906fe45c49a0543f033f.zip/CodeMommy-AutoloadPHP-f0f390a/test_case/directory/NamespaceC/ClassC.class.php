<?php

/**
 * CodeMommy AutoloadPHP
 * @author Candison November <www.kandisheng.com>
 */

namespace Root\NamespaceC;

/**
 * Class ClassC
 * @package Root\NamespaceC
 */
class ClassC
{
    /**
     * ClassC constructor.
     */
    public function __construct()
    {
    }

    /**
     * @return string
     */
    public static function show()
    {
        return 'ClassC';
    }
}
